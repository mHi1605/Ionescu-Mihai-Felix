const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie",
    "Mai", "Iunie", "Iulie", "August",
    "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];
document.getElementById("btnAdauga").addEventListener("click", function () {

    const input = document.getElementById("inputActivitate");
    const text = input.value.trim();

    if (text === "") return;

    const d = new Date();
    const zi = d.getDate();
    const luna = luni[d.getMonth()];
    const an = d.getFullYear();

    const li = document.createElement("li");
    li.textContent = text + " – adăugată la: " + zi + " " + luna + " " + an;

    document.getElementById("listaActivitati").appendChild(li);

    input.value = "";
});
