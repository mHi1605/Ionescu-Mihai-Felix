document.addEventListener("DOMContentLoaded", function () {

    const divDetalii = document.getElementById("detalii");
    const btnDetalii = document.getElementById("btnDetalii");
    const spanData = document.getElementById("dataProdus");
    const luni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];
    const azi = new Date();
    const zi = azi.getDate();
    const luna = luni[azi.getMonth()];
    const an = azi.getFullYear();

    spanData.textContent = `${zi} ${luna} ${an}`;
    btnDetalii.addEventListener("click", function () {

        const ascuns = divDetalii.classList.toggle("ascuns");

        if (ascuns) {
            btnDetalii.textContent = "Afișează detalii";
        } else {
            btnDetalii.textContent = "Ascunde detalii";
        }
    });
});
