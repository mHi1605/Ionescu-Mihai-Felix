<?php session_start(); ?>
<!DOCTYPE html>

<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="cart.php">Cosul Meu</a>
            <a href="despre.php">Despre</a>
            <a href="contact.php">Contact</a>
        </nav>
        
        <div class="account-menu">
            
            
            <?php if (isset($_SESSION['email'])): ?>
                <a href="account.php">
                    <img src="<?php echo isset($_SESSION['profile_pic']) ? htmlspecialchars($_SESSION['profile_pic']) : 'default-avatar.png'; ?>"
                         alt="Profil" class="profile-icon">
                </a>
            <?php else: ?>
                <a href="#" id="loginBtn" class="login-link">Log In / Sign Up</a>
            <?php endif; ?>

        </div>
        </header>

    <section class="hero">
        <div class="hero-content">
            <h2>
                Experimentează sufletul Italiei<br>
                <span style="display:inline-block; margin-top:0.3em;">în fiecare sticlă</span>
            </h2>
            <p>Unde secole de tradiție se întâlnesc cu pasiunea pentru vinificație. Bine ai venit la Casa di Vini.</p>
            <a href="magazin.php" class="btn">Vezi colecția</a>
        </div>
    </section>

    <section class="section">
        <div class="section-title">Vinuri recomandate</div>
        <div class="wines">
            <div class="wine-card">
                <img src="Poze/chianticlassico.png" alt="Chianti Classico">
                <h3>Chianti Classico</h3>
                <p>Bogat, corpolent și atemporal. Un gust din Toscana în fiecare înghițitură.</p>
                <span class="btn btn-small">Detalii</span>
            </div>
            <div class="wine-card">
                <img src="Poze/barollo.png" alt="Barolo">
                <h3>Barolo</h3>
                <p>Regele vinurilor elegant, intens și de neuitat.</p>
                <span class="btn btn-small">Detalii</span>
            </div>
            <div class="wine-card">
                <img src="Poze/prosecco.png" alt="Prosecco">
                <h3>Prosecco</h3>
                <p>Proaspăt, efervescent și plin de bucurie – perfect pentru sărbătoare.</p>
                <span class="btn btn-small">Detalii</span>
            </div>
        </div>

        <div class="about">
            <h2>Despre Casa di Vini</h2>
            <p>
                Casa di Vini este un boutique de familie care selectează cele mai fine vinuri italiene. Pasiunea noastră pentru autenticitate și măiestrie se regăsește în fiecare sticlă, onorând podgoriile însorite și aromele atemporale ale Italiei.
            </p>
        </div>
    </section>

    <footer>
        &copy; 2025 Casa di Vini &mdash; Magazin de vinuri italiene
    </footer>
    
    <?php if (!isset($_SESSION['email'])): ?>
    
        <div id="loginModal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;">
          <div class="account-container" style="max-width:350px;"> <span id="closeModal" style="position:absolute;top:1rem;right:1rem;cursor:pointer;font-size:1.5rem;">&times;</span>
            <h2 class="roman-title" style="font-size:1.5em;">Autentificare / Înregistrare</h2>
            <form method="post" action="login.php" enctype="multipart/form-data">
              <input type="email" name="email" placeholder="Email" required class="roman-input" style="margin-bottom:1em;">
              <input type="text" name="username" placeholder="Username (doar la Sign Up)" class="roman-input" style="margin-bottom:1em;">
              <input type="password" name="password" placeholder="Parolă" required class="roman-input" style="margin-bottom:1em;">
              <input type="file" name="profile_pic" accept="image/jpeg,image/png" class="file-input" style="margin-bottom:1em;">
              <button type="submit" class="primary-btn roman-btn">Log In</button>
              <div style="text-align:center;margin:1em 0; color: var(--color-text-main);">sau</div>
              <button type="submit" name="signup" value="1" class="secondary-btn roman-btn">Sign Up</button>
            </form>
          </div>
        </div>

        <script>
        document.getElementById('loginBtn').onclick = function(e) {
            e.preventDefault(); // Oprește navigarea implicită
            document.getElementById('loginModal').style.display = 'flex';
        };
        document.getElementById('closeModal').onclick = function() {
            document.getElementById('loginModal').style.display = 'none';
        };
        window.onclick = function(event) {
            if (event.target == document.getElementById('loginModal')) {
                document.getElementById('loginModal').style.display = 'none';
            }
        };
        </script>
    <?php endif; ?>
<a href="#top" id="backToTop">⬆ Mergi sus</a>
    <script src="script.js"></script>
</body>
</html>