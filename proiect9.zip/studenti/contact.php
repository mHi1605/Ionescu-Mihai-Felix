<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nume = htmlspecialchars($_POST["nume"]);
    $email = htmlspecialchars($_POST["email"]);
    $mesaj = htmlspecialchars($_POST["mesaj"]);

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mihai.ionescu1605@gmail.com';
        $mail->Password = 'inqx pusx sbkx elpt';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom($email, $nume);
        $mail->addAddress('mihai.ionescu1605@gmail.com');

        $mail->Subject = 'Mesaj nou de pe Casa di Vini';
        $mail->Body    = "Nume: $nume\nEmail: $email\nMesaj:\n$mesaj";

        $mail->send();
        $raspuns = "<div style='color:green;text-align:center;'>Mesajul a fost trimis cu succes!</div>";
    } catch (Exception $e) {
        $raspuns = "<div style='color:red;text-align:center;'>Eroare la trimiterea mesajului: {$mail->ErrorInfo}</div>";
    }
}
?>
<?php if (isset($raspuns)) echo $raspuns; ?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Contact | Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="despre.php">Despre</a>
        </nav>
    </header>

    <section class="section">
        <div class="section-title">Contact</div>
        <div class="about">
            <h2>Ia legătura cu noi</h2>
            <p>
                Pentru întrebări, recomandări sau colaborări, ne poți contacta folosind formularul de mai jos sau la datele de contact.
            </p>
            <form method="POST" action="contact.php" style="max-width:400px;margin:auto;">
                <label for="nume">Nume:</label>
                <input type="text" id="nume" name="nume" required style="width:100%;padding:0.5em;margin-bottom:1em;border-radius:6px;border:1px solid #cbb19c;">
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required style="width:100%;padding:0.5em;margin-bottom:1em;border-radius:6px;border:1px solid #cbb19c;">
                
                <label for="mesaj">Mesaj:</label>
                <textarea id="mesaj" name="mesaj" rows="5" required style="width:100%;padding:0.5em;margin-bottom:1em;border-radius:6px;border:1px solid #cbb19c;"></textarea>
                
                <button type="submit" class="btn">Trimite</button>
            </form>
            <h2 style="margin-top:2.5rem;">Date de contact</h2>
            <ul style="font-size:1.15rem;line-height:1.7;">
                <li>Email: contact@casadivini.ro</li>
                <li>Telefon: 0722 123 456</li>
                <li>Adresă: Str. Degustării nr. 10, București</li>
            </ul>
        </div>
    </section>

    <footer>
        &copy; 2025 Casa di Vini &mdash; Magazin de vinuri italiene
    </footer>
    
    <script src="script.js"></script>
</body>
</html>