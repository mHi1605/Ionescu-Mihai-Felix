<?php
// orders.php

// 1. **Pornirea Sesiunii și Verificarea Autentificării**
session_start();

if (!isset($_SESSION['email'])) {
    // Redirecționează utilizatorul nelogat
    header('Location: login.php'); 
    exit();
}

$user_email = $_SESSION['email']; 

// 2. **Detalii de Conexiune la Baza de Date (mysqli)**
$servername = "lamp_mysql"; 
$username = "user";
$password = "password";
$dbname = "studenti";
$port = 3306; 

// 3. **Inițializarea Variabilelor**
$orders = []; 
$error_message = '';
// Preluare din Sesiune, cu valori de rezervă sigure
$user_username = $_SESSION['username'] ?? explode('@', $user_email)[0]; 
$profile_pic = $_SESSION['profile_pic'] ?? 'path/to/default-profile.jpg'; 

// Funcție ajutătoare pentru status (pentru stilul CSS)
function get_status_class($status_text) {
    if ($status_text === 'Livrată') {
        return 'status-livrata';
    } elseif ($status_text === 'În procesare') {
        return 'status-procesare';
    }
    return '';
}

// 4. **Conectarea și Preluarea Datelor**
try {
    // CORECȚIE 1: Ordinea corectă a argumentelor: Host, User, Pass, DB_Name, Port
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    
    // Verifică erorile de conexiune
    if ($conn->connect_error) {
        throw new Exception("Conexiune eșuată: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");


    // 5. Preluarea Comenzilor Utilizatorului (CORECTAT PENTRU data_plasare)
    // Selectăm coloanele esențiale: id, data_plasare, total, detalii și status.
    $stmt_orders = $conn->prepare("SELECT id, data_plasare, total, detalii, status FROM comenzi WHERE user_email = ? ORDER BY data_plasare DESC");
    
    // ATENȚIE: Am înlocuit email cu user_email în WHERE clause pentru a se potrivi cu structura ta!
    $stmt_orders->bind_param("s", $user_email);
    $stmt_orders->execute();
    
    $result = $stmt_orders->get_result();
    $orders = $result->fetch_all(MYSQLI_ASSOC);
    $stmt_orders->close();
    
    // Procesare simplă a detaliilor (presupunem că e un string/JSON)
    foreach($orders as &$order) {
        // Dacă coloana 'detalii' conține un rezumat al produselor
        $order['rezumat_produse'] = !empty($order['detalii']) ? substr(strip_tags($order['detalii']), 0, 50) . '...' : 'Detalii necunoscute';
    }

} catch (Exception $e) {
    // În caz de eroare, afișăm mesajul și lăsăm $orders ca array gol
    $error_message = "Eroare la baza de date: " . $e->getMessage();
} finally {
    // Închidem conexiunea în orice caz
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comenzile Mele - Casa di Vini</title>
    <link rel="stylesheet" href="../style.css"> 
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

    <header>
        <h1>CASA DI VINI</h1> 
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="cart.php">Coș (<?php echo count($_SESSION['cart'] ?? []); ?>)</a>
            <a href="orders.php" style="color: #d9a86c;">Comenzile Mele</a>
            <a href="contact.php">Contact</a>
        </nav>
        
        <div class="account-menu">
            <img src="<?php echo $profile_pic; ?>" alt="Profil" class="profile-icon">
            <div class="profile-dropdown">
                <span class="account-username"><?php echo htmlspecialchars($user_username); ?></span>
                <a href="account.php" class="btn btn-small">Contul Meu</a>
                <a href="logout.php" class="btn btn-small btn-logout">Delogare</a>
            </div>
        </div>
    </header>

    <div class="hero" style="min-height: 180px;">
        <div class="hero-content">
            <h2>Comenzile <span>Lui <?php echo htmlspecialchars($user_username); ?></span></h2>
        </div>
    </div>
    
    <div class="section">
        <h2 class="section-title">Istoricul Comenzilor</h2>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert-error" style="max-width: 800px; margin: 1em auto;">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <?php if (count($orders) > 0): ?>
            <div class="orders-list">
                
                <?php foreach ($orders as $order): ?>
                    <div class="order-card">
                        <h3>Comanda #<?php echo htmlspecialchars($order['id']); ?></h3>
                        
                        <div class="order-details-summary">
                            <p style="font-weight: 600; margin-bottom: 0.3em; color: #4c0e17;">Rezumat Produse:</p>
                            <p style="margin: 0.3em 0;">
                                <?php echo htmlspecialchars($order['rezumat_produse']); ?>
                            </p>
                            <p>
                                <strong>Total:</strong> <?php echo htmlspecialchars(number_format($order['total'] ?? 0, 2)); ?> RON
                            </p>
                        </div>

                        <p><strong>Dată Plasare:</strong> <?php echo date('d.m.Y H:i', strtotime(htmlspecialchars($order['data_plasare']))); ?></p>
                        
                        <p><strong>Status:</strong> 
                            <span class="<?php echo get_status_class(htmlspecialchars($order['status'])); ?>">
                                <?php echo htmlspecialchars($order['status']); ?>
                            </span>
                        </p>
                        
                        <a href="view_order.php?id=<?php echo htmlspecialchars($order['id']); ?>" class="btn btn-small btn-orders">Vizualizează Detalii</a>
                    </div>
                <?php endforeach; ?>
            </div>

        <?php else: ?>
            <div class="about" style="text-align: center;">
                <h2 class="section-title">Nicio Comandă Găsită</h2>
                <p>Nu ai plasat încă nicio comandă asociată cu emailul **<?php echo htmlspecialchars($user_email); ?>**.</p>
                <a href="magazin.php" class="btn">Explorează Vinurile</a>
            </div>
        <?php endif; ?>

    </div>

    <footer>
        &copy; <?php echo date('Y'); ?> Casa di Vini | Toate drepturile rezervate.
    </footer>

    <script src="script.js"></script>
</body>
</html>