<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

// Inițializare variabile de mesaj și director de încărcare
$mesaj = '';
$culoare = '';
if (!is_dir('uploads')) {
    mkdir('uploads', 0755, true);
}

// Logica de procesare a formularului
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Actualizare Username
    if (!empty($_POST['username'])) {
        $_SESSION['username'] = htmlspecialchars($_POST['username']);
        $mesaj = "Username actualizat!";
        $culoare = "success";
    }
    // Actualizare Poza de Profil
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
            $newName = uniqid('profile_', true) . '.' . $ext;
            $target = 'uploads/' . $newName;
            if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target)) {
                $_SESSION['profile_pic'] = $target;
                $mesaj = "Poza de profil actualizată!";
                $culoare = "success";
            } else {
                $mesaj = "Eroare la încărcarea pozei!";
                $culoare = "error";
            }
        } else {
            $mesaj = "Doar fișiere JPG/PNG sunt permise!";
            $culoare = "error";
        }
    }
}

// Variabile de afișare (default)
$current_username = isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Utilizator Nobil';
$current_profile_pic = isset($_SESSION['profile_pic']) ? htmlspecialchars($_SESSION['profile_pic']) : 'default-avatar.png';
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contul meu Nobil | Casa di Vini</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
</head>
<body class="roman-theme">

    <div class="column left-column">
    </div>

    <div class="main-content">

        <div class="account-container roman-border">
                    <button id="theme-toggle" class="roman-btn secondary-btn" style="width: 100%; margin-bottom: 20px;">
                🌞 Comută Tema / 🌙
            </button>
            <h1 class="roman-title">Contul meu</h1>
            
            <?php if ($mesaj): ?>
                <div class="alert-message alert-<?php echo $culoare; ?>">
                    <?php echo htmlspecialchars($mesaj); ?>
                </div>
            <?php endif; ?>

            <div class="profile-header">
                <img src="<?php echo $current_profile_pic; ?>" 
                    alt="Profil" class="profile-avatar roman-avatar">
            </div>

            <form method="post" enctype="multipart/form-data" class="profile-form">
                <div class="form-group">
                    <label for="username" class="roman-label">Nume de Utilizator (Username):</label>
                    <input type="text" id="username" name="username" value="<?php echo $current_username; ?>" class="roman-input">
                </div>
                
                <div class="form-group file-upload">
                    <label for="profile_pic" class="roman-label">Schimbă Poza de Profil:</label>
                    <input type="file" id="profile_pic" name="profile_pic" accept="image/jpeg,image/png" class="file-input">
                </div>
                
                <button type="submit" class="btn roman-btn primary-btn">Salvează Schimbările</button>
            </form>

            <div class="account-btns">
                <a href="orders.php" class="btn roman-btn secondary-btn">Comenzile Mele (Tabula Mandatorum)</a>
                <a href="index.php" class="btn roman-btn secondary-btn">Acasă (Domus)</a>
            </div>
            
            <a href="logout.php" class="btn roman-btn logout-btn">Părăsește Sesiunea (Logout)</a>
        </div>
    </div>

    <div class="column right-column">
    </div>
    
    <script src="script.js"></script>
</body>
</html>