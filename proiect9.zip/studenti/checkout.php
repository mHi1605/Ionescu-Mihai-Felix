<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php'; 
//connectare la docker
$servername = "lamp_mysql"; 
$username = "user";
$password = "password";
$dbname = "studenti";
$port = 3306;

//config pt phpmailer
$smtp_host = 'smtp.gmail.com'; 
$smtp_port = 587;
$smtp_user = 'mihai.ionescu1605@gmail.com'; 
$smtp_pass = 'vwyj fmyz bcno owsy';
$admin_email = 'mihai.ionescu1605@gmail.com';

$cart_items = $_SESSION['cart'] ?? [];
$cart_count = count($cart_items);

if ($cart_count === 0) {
    header('Location: cart.php');
    exit();
}
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

$user_email_session = $_SESSION['email']; 
$total_price = 0;
$checkout_status = ''; 
$error_type = '';

foreach ($cart_items as $item) {
    $total_price += $item['price'] * $item['quantity'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalize_order'])) {
    $nume_complet = trim($_POST['nume_complet'] ?? '');
    $adresa_livrare = trim($_POST['adresa_livrare'] ?? '');
    $oras = trim($_POST['oras'] ?? '');
    $telefon = trim($_POST['telefon'] ?? '');
    $metoda_plata = $_POST['metoda_plata'] ?? 'Ramburs';
    if (empty($nume_complet) || empty($adresa_livrare) || empty($oras) || empty($telefon)) {
        $checkout_status = "Toate câmpurile de livrare sunt obligatorii!";
        $error_type = 'error';
    } else {
        try {
            $conn = new mysqli($servername, $username, $password, $dbname, $port);
            if ($conn->connect_error) {
                throw new Exception("Conexiune eșuată la BD: " . $conn->connect_error);
            }
            if (!$conn->set_charset("utf8mb4")) {
                 error_log("Eroare la setarea charset-ului: " . $conn->error);
            }
            
            $detalii_json = json_encode($cart_items, JSON_UNESCAPED_UNICODE);
            $status = 'Nouă'; 
            $stmt = $conn->prepare("INSERT INTO comenzi 
                (user_email, nume_complet, adresa_livrare, oras, telefon, total, detalii, status, metoda_plata) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                
            $stmt->bind_param("sssssdsss", 
                $user_email_session, $nume_complet, $adresa_livrare, $oras, $telefon, 
                $total_price, $detalii_json, $status, $metoda_plata        
            );
            
            if ($stmt->execute()) {
                $order_id = $conn->insert_id;
                try {
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host       = $smtp_host;
                    $mail->SMTPAuth   = true;
                    $mail->Username   = $smtp_user;
                    $mail->Password   = $smtp_pass;
                    $mail->SMTPSecure = 'tls'; 
                    $mail->Port       = $smtp_port;
                    $mail->CharSet = 'UTF-8';
                    $mail->setFrom($smtp_user, 'Casa di Vini');
                    $mail_body = "
                        <html><body style='font-family: Arial, sans-serif; line-height: 1.6; color: #444;'>
                        <div style='max-width: 600px; margin: 0 auto; border: 1px solid #d9a86c; padding: 20px;'>
                            <h2 style='color: #801f2f;'>Comanda plasată cu succes! (#{$order_id})</h2>
                            <p>Îți mulțumim pentru comanda plasată la Casa di Vini, **{$nume_complet}**.</p>
                            <hr style='border: 0; border-top: 1px solid #eee;'>
                            <h4 style='color: #4c0e17;'>Detalii Livrare:</h4>
                            <ul style='list-style: none; padding: 0;'>
                                <li>**Email:** {$user_email_session}</li>
                                <li>**Adresă:** {$adresa_livrare}, {$oras}</li>
                                <li>**Telefon:** {$telefon}</li>
                                <li>**Metodă plată:** {$metoda_plata}</li>
                            </ul>
                            <h4 style='color: #4c0e17;'>Sumar Comandă:</h4>
                            <table border='1' cellpadding='10' cellspacing='0' width='100%' style='border-collapse: collapse;'>
                                <tr style='background-color: #f5f0eb;'><th>Produs</th><th>Cantitate</th><th>Preț</th><th>Subtotal</th></tr>";
                                
                    foreach ($cart_items as $item) {
                        $subtotal = $item['price'] * $item['quantity'];
                        $mail_body .= "<tr>
                                            <td>" . htmlspecialchars($item['name']) . "</td>
                                            <td style='text-align: center;'>{$item['quantity']}</td>
                                            <td>" . number_format($item['price'], 2, ',', '.') . " RON</td>
                                            <td>" . number_format($subtotal, 2, ',', '.') . " RON</td>
                                        </tr>";
                    }
                    $mail_body .= "</table>
                            <h3 style='color: #801f2f; text-align: right;'>TOTAL: " . number_format($total_price, 2, ',', '.') . " RON</h3>
                        </div></body></html>";
                    $mail->addAddress($user_email_session, $nume_complet);
                    $mail->isHTML(true);
                    $mail->Subject = 'Confirmare Comanda Casa di Vini #' . $order_id;
                    $mail->Body    = $mail_body;
                    $mail->send();
                    $mail->clearAddresses();
                    $mail->addAddress($admin_email, 'Administrator Comenzi');
                    $mail->Subject = '[NOU] Comandă #' . $order_id . ' de la ' . $nume_complet;
                    $mail->Body    = "S-a plasat o comandă nouă. Detalii complete mai jos:<br><br>" . $mail_body;
                    $mail->send();

                    $checkout_status = "Comanda ta (#{$order_id}) a fost plasată cu succes! Vei primi un email de confirmare și vei fi redirecționat.";

                } catch (Exception $mail_e) {
                    $checkout_status = "Comanda a fost salvată, dar eroarea la trimiterea emailului: " . $mail_e->getMessage();
                }
                unset($_SESSION['cart']); 
                $error_type = 'success';
                header("Refresh: 3; URL=index.php"); 
                
            } else {
                $checkout_status = "Eroare la înregistrarea comenzii: " . $stmt->error;
                $error_type = 'error';
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $checkout_status = "Eroare de sistem: " . $e->getMessage();
            $error_type = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Finalizare Comandă | Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .checkout-form { max-width: 600px; margin: 0 auto 30px; padding: 30px; border: 1px solid #d8c2b0; border-radius: 8px; background-color: #fcfaf8; }
        .checkout-form label { display: block; margin-top: 15px; margin-bottom: 5px; font-weight: 600; color: #4c0e17; }
        .checkout-form input[type="text"], .checkout-form textarea, .checkout-form select { width: 100%; padding: 10px; border: 1px solid #d8c2b0; border-radius: 4px; box-sizing: border-box; }
        .order-summary { background-color: #eee; padding: 20px; margin-top: 20px; border-radius: 4px; }
        .order-summary .total { font-size: 1.5em; font-weight: 700; color: #801f2f; margin-top: 10px; border-top: 1px dashed #d8c2b0; padding-top: 10px; }
        .alert-success { background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px; }
        .alert-error { background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px; }
    </style>
</head>
<body>
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="cart.php">Coș (<?php echo $cart_count; ?>)</a>
            <a href="despre.php">Despre</a>
            <a href="contact.php">Contact</a>
            <?php if (isset($_SESSION['email'])): ?>
                <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['email']); ?>)</a>
            <?php else: ?>
                <a href="login.php">Login / Înregistrare</a>
            <?php endif; ?>
        </nav>
    </header>

    <section class="section">
        <h2 class="section-title">Finalizare Comandă</h2>
        
        <?php if ($checkout_status): ?>
            <div class="checkout-form <?php echo ($error_type === 'error' ? 'alert-error' : 'alert-success'); ?>">
                <?php echo htmlspecialchars($checkout_status); ?>
                <?php if ($error_type === 'success'): ?>
                    <p>Vei fi redirecționat automat...</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_type !== 'success'): ?>
        
        <form action="checkout.php" method="POST" class="checkout-form">
            <h3>Detalii Livrare</h3>
            <label for="nume_complet">Nume Complet:</label>
            <input type="text" id="nume_complet" name="nume_complet" required>
            <label for="adresa_livrare">Adresă Completă:</label>
            <textarea id="adresa_livrare" name="adresa_livrare" rows="3" required></textarea>
            <label for="oras">Oraș/Localitate:</label>
            <input type="text" id="oras" name="oras" required>
            <label for="telefon">Telefon:</label>
            <input type="text" id="telefon" name="telefon" required>
            <hr style="margin: 20px 0;">
            <h3>Metodă de Plată</h3>
            <label for="metoda_plata">Alege Metoda:</label>
            <select id="metoda_plata" name="metoda_plata" required>
                <option value="Ramburs">Plată la livrare (Ramburs)</option>
                <option value="Card" disabled>Plată cu Cardul (Indisponibil)</option>
            </select>
            
            <div class="order-summary">
                <h4>Sumar Comandă (<?php echo $cart_count; ?> produse)</h4>
                <?php foreach ($cart_items as $item): ?>
                    <p>
                        <?php echo htmlspecialchars($item['quantity']); ?> x <?php echo htmlspecialchars($item['name']); ?> 
                        <span style="float: right;"><?php echo number_format($item['price'] * $item['quantity'], 2, ',', '.'); ?> RON</span>
                    </p>
                <?php endforeach; ?>
                <div class="total">
                    TOTAL DE PLATĂ: <?php echo number_format($total_price, 2, ',', '.'); ?> RON
                </div>
            </div>

            <button type="submit" name="finalize_order" class="btn" style="margin-top: 20px; width: 100%;">
                Plasează Comanda
            </button>
        </form>
        
        <?php endif; ?>
        
    </section>

    <footer>
        &copy; <?php echo date('Y'); ?> Casa di Vini &mdash; Magazin de vinuri italiene
    </footer>
    
    <script src="script.js"></script>
</body>
</html>