USE studenti;
CREATE TABLE comenzi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    produs VARCHAR(255) NOT NULL,
    cantitate INT NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE utilizatori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    parola VARCHAR(255) NOT NULL,
    username VARCHAR(255),
    poza VARCHAR(255)
);
Use studenti;
CREATE TABLE produse (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(255) NOT NULL,
    descriere TEXT,
    pret DECIMAL(10, 2) NOT NULL,
    imagine_url VARCHAR(255),
    stoc INT DEFAULT 0,
    UNIQUE KEY uk_nume (nume)
);
INSERT INTO produse (nume, descriere, pret, imagine_url, stoc) VALUES
('Chianti Classico', 'Bogat, corpolent și atemporal. Un gust din Toscana în fiecare înghițitură.', 75.99, 'Poze/chianticlassico.png', 50),
('Barolo', 'Regele vinurilor  elegant, intens și de neuitat.', 120.50, 'Poze/barollo.png', 30),
('Prosecco', 'Proaspăt, efervescent și plin de bucurie  perfect pentru sărbătoare.', 45.00, 'Poze/prosecco.png', 80),
('Montepulciano d\'Abruzzo', 'Vin roșu intens, cu note de fructe negre și tanini fini.', 62.75, 'Poze/Montepulciano d\'Abruzzo.png', 45),
('Pinot Grigio', 'Alb sec, proaspăt, cu arome de citrice și mere verzi.', 55.49, 'Poze/Pinot Grigio.png', 60);