<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Schimbă calea dacă este necesar
require __DIR__ . '/vendor/autoload.php'; 

$mesaj = '';
$culoare = '';

// Detalii de Conexiune (duplicate pentru siguranță, deși ar trebui să fie într-un fișier separat)
$servername = "lamp_mysql"; 
$db_username = "user";
$db_password = "password";
$dbname = "studenti";
$port = 3306;


function is_valid_username($username) {
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
}

function is_valid_image($file) {
    $allowed = ['image/jpeg', 'image/png'];
    return in_array($file['type'], $allowed) && $file['size'] <= 2 * 1024 * 1024;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifică ce formular a fost trimis
    $signup_attempt = isset($_POST['signup']);

    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $profile_pic = null;

    if ($signup_attempt && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // --- LOGICA DE ÎNREGISTRARE (Signup) ---
        
        if (strlen($password) < 6) {
             $mesaj = "Parola trebuie să aibă minim 6 caractere.";
             $culoare = "error";
        } elseif (!is_valid_username($username)) {
             $mesaj = "Username invalid! Folosește 3-20 caractere, doar litere, cifre și _";
             $culoare = "error";
        } else {
            // Logica de încărcare poză
            if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
                if (is_valid_image($_FILES['profile_pic'])) {
                    if (!is_dir('uploads')) mkdir('uploads', 0755, true);
                    $ext = strtolower(pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION));
                    $newName = uniqid('profile_', true) . '.' . $ext;
                    $target = 'uploads/' . $newName;
                    if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target)) {
                        $profile_pic = $target;
                    } else {
                        $mesaj = "Eroare la încărcarea pozei!"; $culoare = "error";
                    }
                } else {
                    $mesaj = "Poza trebuie să fie JPG sau PNG și max 2MB!"; $culoare = "error";
                }
            }

            if (!$mesaj) {
                $conn = new mysqli($servername, $db_username, $db_password, $dbname, $port);
                if ($conn->connect_error) die("Conexiune eșuată!");
                $conn->set_charset("utf8mb4");

                // Verifică dacă emailul există deja
                $stmt = $conn->prepare("SELECT id FROM utilizatori WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {
                    $mesaj = "Email deja folosit!"; $culoare = "error";
                } else {
                    $stmt->close();
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    // Daca poza nu a fost incarcata, foloseste 'default-avatar.png'
                    $final_poza = $profile_pic ?: 'default-avatar.png'; 
                    
                    $stmt = $conn->prepare("INSERT INTO utilizatori (email, parola, username, poza) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssss", $email, $password_hash, $username, $final_poza);
                    
                    if ($stmt->execute()) {
                        // Trimitere email de confirmare
                        $mail = new PHPMailer(true);
                        try {
                            $mail->isSMTP();
                            $mail->Host = 'smtp.gmail.com';
                            $mail->SMTPAuth = true;
                            $mail->Username = 'mihai.ionescu1605@gmail.com';
                            $mail->Password = 'vwyj fmyz bcno owsy';
                            $mail->SMTPSecure = 'tls';
                            $mail->Port = 587;
                            $mail->CharSet = 'UTF-8';

                            $mail->setFrom('mihai.ionescu1605@gmail.com', 'Casa di Vini');
                            $mail->addAddress($email);

                            $mail->Subject = 'Confirmare înregistrare Casa di Vini';
                            $mail->Body = "Bun venit, $username!\nContul tău a fost creat cu succes pe Casa di Vini. Te poți loga acum.";
                            $mail->send();
                            
                            $mesaj = "Cont creat! Verifică emailul pentru confirmare. Te rugăm să te loghezi acum.";
                            $culoare = "success";
                        } catch (Exception $e) {
                            $mesaj = "Cont creat, dar emailul nu a putut fi trimis: {$mail->ErrorInfo}";
                            $culoare = "error";
                        }
                    } else {
                        $mesaj = "Eroare la înregistrare în baza de date!"; $culoare = "error";
                    }
                }
                $stmt->close();
                $conn->close();
            }
        } // Sfârșit Logica de înregistrare

    } elseif (!$signup_attempt) {
        
        // --- LOGICA DE LOGARE (Login) ---
        
        $conn = new mysqli($servername, $db_username, $db_password, $dbname, $port);
        if ($conn->connect_error) die("Conexiune eșuată!");
        $conn->set_charset("utf8mb4");

        $stmt = $conn->prepare("SELECT parola, username, poza FROM utilizatori WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($parola_hash, $username, $poza);
            $stmt->fetch();
            
            // Verificarea parolei hash
            if (password_verify($password, $parola_hash)) {
                
                // AUTENTIFICARE REUȘITĂ
                $_SESSION['email'] = $email;
                // Folosește un nume de utilizator implicit dacă e NULL/gol
                $_SESSION['username'] = !empty($username) ? $username : explode('@', $email)[0]; 
                $_SESSION['profile_pic'] = !empty($poza) ? $poza : 'default-avatar.png';
                
                // Redirecționare
                header("Location: magazin.php"); 
                exit; 
            } else {
                $mesaj = "Parolă greșită!";
                $culoare = "error";
            }
        } else {
            $mesaj = "Email inexistent!";
            $culoare = "error";
        }
        $stmt->close();
        $conn->close();

    } else {
        $mesaj = "Email invalid!";
        $culoare = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Login | Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Stiluri pentru a așeza eticheta și inputul pe rânduri separate (Corecția solicitată) */
        .auth-container { 
            display: flex; 
            max-width: 800px; 
            margin: 40px auto; 
            gap: 30px; 
        }
        .auth-form { 
            flex: 1; 
            padding: 20px 30px; /* Mai mult padding */
            border: 1px solid #d8c2b0; 
            border-radius: 8px; 
            background-color: #fcfaf8; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        
        /* CORECȚIE CRITICĂ: Face eticheta să ocupe rândul, forțând inputul sub ea */
        .auth-form label { 
            display: block; 
            margin-top: 15px; 
            margin-bottom: 5px; 
            font-weight: 600; 
            color: #4c0e17; 
            text-align: left; /* Aliniază textul etichetei la stânga */
        }
        
        /* Stilul comun pentru input-uri */
        .auth-form input[type="email"], 
        .auth-form input[type="password"], 
        .auth-form input[type="text"],
        .auth-form input[type="file"] { 
            width: 100%; 
            padding: 10px; 
            margin-bottom: 15px; 
            border: 1px solid #d8c2b0; 
            border-radius: 4px; 
            box-sizing: border-box; 
        }

        /* Stil pentru alertă */
        .alert-error { background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px; border: 1px solid #f5c6cb; }
        .alert-success { background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px; border: 1px solid #c3e6cb; }

        /* Stil specific pentru input[type="file"] */
        .auth-form input[type="file"] {
            padding: 5px;
            border: none;
        }

        @media (max-width: 800px) {
            .auth-container {
                flex-direction: column;
                max-width: 95%;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="cart.php">Coș (<?php echo count($_SESSION['cart'] ?? []); ?>)</a>
            <a href="despre.php">Despre</a>
            <a href="contact.php">Contact</a>
            <a href="login.php" style="color: #d9a86c;">Login / Înregistrare</a>
        </nav>
    </header>
    <section class="section">
        <h2 class="section-title">Autentificare / Înregistrare</h2>
        
        <?php if (!empty($mesaj)): ?>
            <div class="alert-<?php echo $culoare; ?>" style="max-width: 800px; margin: 20px auto;">
                <?php echo htmlspecialchars($mesaj); ?>
            </div>
        <?php endif; ?>

        <div class="auth-container">
            <form action="login.php" method="POST" class="auth-form">
                <h3>Login</h3>
                
                <label for="email_login">Adresa de email:</label>
                <input type="email" id="email_login" name="email" required>
                
                <label for="password_login">Parola:</label>
                <input type="password" id="password_login" name="password" required>
                
                <button type="submit" name="login" class="btn" style="width: 100%; margin-top: 20px;">Login</button>
            </form>

            <form action="login.php" method="POST" class="auth-form" enctype="multipart/form-data">
                <h3>Înregistrare (Nou Cont)</h3>
                
                <label for="email_signup">Email:</label>
                <input type="email" id="email_signup" name="email" required>
                
                <label for="username_signup">Username:</label>
                <input type="text" id="username_signup" name="username" required>
                
                <label for="password_signup">Parola:</label>
                <input type="password" id="password_signup" name="password" required>

                <label for="profile_pic">Poză Profil (Opțional, max 2MB):</label>
                <input type="file" id="profile_pic" name="profile_pic" accept="image/jpeg,image/png">
                
                <input type="hidden" name="signup" value="1">
                <button type="submit" class="btn" style="width: 100%; margin-top: 20px;">Înregistrare</button>
            </form>
        </div>
    </section>
    <footer>
        &copy; <?php echo date('Y'); ?> Casa di Vini
    </footer>
    
    <script src="script.js"></script>
</body>
</html>