-- auto-generated definition
create table produse
(
    id          int auto_increment
        primary key,
    nume        varchar(255)   not null,
    descriere   text           null,
    pret        decimal(10, 2) not null,
    imagine_url varchar(255)   null,
    stoc        int default 0  null,
    constraint uk_nume
        unique (nume)
);

