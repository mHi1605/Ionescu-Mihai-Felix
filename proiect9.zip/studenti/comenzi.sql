-- auto-generated definition
create table comenzi
(
    id             int auto_increment
        primary key,
    user_email     varchar(255)                                                               not null,
    data_plasare   datetime                                         default CURRENT_TIMESTAMP null,
    nume_complet   varchar(255)                                                               not null,
    adresa_livrare text                                                                       not null,
    oras           varchar(100)                                                               not null,
    telefon        varchar(20)                                                                null,
    total          decimal(10, 2)                                                             not null,
    detalii        json                                                                       null,
    status         enum ('Nouă', 'Procesată', 'Livrată', 'Anulată') default 'Nouă'            null,
    metoda_plata   varchar(50)                                                                null
);

