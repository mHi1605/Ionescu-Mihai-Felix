<?php
session_start();

//conectare l docker
$servername = "lamp_mysql"; 
$username = "user";
$password = "password";
$dbname = "studenti";
$port = 3306;

// Inițializare variabile
$wines = []; 
$error_message = '';

// Inițializare coș (dacă nu există)
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// ===================================
// A. LOGICA DE ADĂUGARE ÎN COȘ
// ===================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = (int)$_POST['product_id'];
    
    try {
        $conn = new mysqli($servername, $username, $password, $dbname, $port);
        if ($conn->connect_error) {
            // Dacă nu se poate conecta, arată eroarea, dar nu opri scriptul brusc (pentru a afișa eroarea)
            $error_message = "Eroare de conexiune la BD: " . $conn->connect_error;

        }
        
        // Preluăm detaliile produsului (nume, preț, imagine) și verificăm stocul
        $stmt = $conn->prepare("SELECT id, nume, pret, imagine_url FROM produse WHERE id = ? AND stoc > 0");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product_to_add = $result->fetch_assoc();
        $stmt->close();
        $conn->close();

        if ($product_to_add) {
            $id = $product_to_add['id'];
            if (isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id]['quantity'] += 1;
            } else {
                $_SESSION['cart'][$id] = [
                    'id' => $id,
                    'name' => $product_to_add['nume'],
                    'price' => (float)$product_to_add['pret'],
                    'img' => $product_to_add['imagine_url'],
                    'quantity' => 1
                ];
            }
            // Redirecționează cu succes
            header('Location: magazin.php?status=added');
            exit();
        } else {
            $error_message = "Produsul nu există sau este momentan epuizat!";
        }

    } catch (Exception $e) {
        $error_message = "Eroare la adăugarea în coș: " . $e->getMessage();
    }
}
//Preluare produse din BD
try {
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    if ($conn->connect_error) {
        if (empty($error_message)) {
             $error_message = "Eroare la preluarea produselor: " . $conn->connect_error;
        }
        // Nu este nevoie să aruncăm excepție aici, continuăm cu array gol
    } else {
        $query = "SELECT id, nume, descriere, pret, imagine_url FROM produse WHERE stoc > 0 ORDER BY nume ASC";
        $result = $conn->query($query);
        
        if ($result) {
            $wines = $result->fetch_all(MYSQLI_ASSOC);
        }
        $conn->close();
    }
} catch (Exception $e) {
    // Mesajul de eroare va fi afișat în HTML
    $error_message = "Eroare la preluarea produselor: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Magazin | Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="cart.php">Coș (<?php echo count($_SESSION['cart']); ?>)</a>
            <a href="despre.php">Despre</a>
            <a href="contact.php">Contact</a>
        </nav>
    </header>

    <section class="section">
        <h2 class="section-title">Magazinul nostru de vinuri</h2>
        
        <?php if (!empty($error_message)): ?>
            <div style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px;">
                Eroare: <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['status']) && $_GET['status'] === 'added'): ?>
            <div style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px;">
                Produs adăugat în coș! <a href="cart.php" style="font-weight: bold;">Vizualizează coșul (<?php echo count($_SESSION['cart']); ?>).</a>
            </div>
        <?php endif; ?>

        <div class="wines">
            <?php if (empty($wines)): ?>
                <p style="text-align: center; width: 100%; font-size: 1.1em; color: #801f2f;">
                    În prezent, nu avem produse disponibile în stoc. Reveniți curând!
                </p>
            <?php endif; ?>
            
            <?php foreach ($wines as $wine): ?>
            <div class="wine-card">
                <img src="<?php echo htmlspecialchars($wine['imagine_url']); ?>" alt="<?php echo htmlspecialchars($wine['nume']); ?>">
                <h3><?php echo htmlspecialchars($wine['nume']); ?></h3>
                <p><?php echo htmlspecialchars($wine['descriere']); ?></p>
                <p class="price" style="font-weight: bold; color: #801f2f; margin-bottom: 15px;">
                    <?php echo number_format($wine['pret'], 2, ',', '.'); ?> RON
                </p>
                
                <form action="magazin.php" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $wine['id']; ?>">
                    <button type="submit" name="add_to_cart" class="btn btn-small">
                        Adaugă în coș
                    </button>
                </form>

            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <footer>
        &copy; <?php echo date('Y'); ?> Casa di Vini &mdash; Magazin de vinuri italiene
    </footer>
    
    <script src="script.js"></script>
</body>
</html>