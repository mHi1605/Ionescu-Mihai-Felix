<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_SESSION['email'];
    $produs = $_POST['produs'];
    $cantitate = $_POST['cantitate'];

    $conn = new mysqli("localhost", "root", "parola_mysql", "nume_baza_date");
    if ($conn->connect_error) die("Conexiune eșuată!");

    $stmt = $conn->prepare("INSERT INTO comenzi (email, produs, cantitate) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $email, $produs, $cantitate);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header("Location: orders.php");
    exit;
}
?>