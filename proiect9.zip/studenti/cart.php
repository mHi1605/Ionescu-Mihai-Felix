<?php
session_start();
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$cart_items = $_SESSION['cart'];
$total_price = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = (int)$_POST['product_id'];
    
    if (isset($_POST['update_quantity']) && isset($cart_items[$product_id])) {
        $action = $_POST['update_quantity'];
        
        if ($action === 'increase') {
            $_SESSION['cart'][$product_id]['quantity'] += 1;
        } elseif ($action === 'decrease' && $_SESSION['cart'][$product_id]['quantity'] > 1) {
            $_SESSION['cart'][$product_id]['quantity'] -= 1;
        }
    }
    
    if (isset($_POST['remove_item'])) {
        if (isset($_SESSION['cart'][$product_id])) {
            unset($_SESSION['cart'][$product_id]);
        }
    }
    header('Location: cart.php');
    exit();
}
foreach ($cart_items as $item) {
    $total_price += $item['price'] * $item['quantity'];
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Coșul Meu | Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
    .cart-table {
            width: 80%;
            margin: 2rem auto;
            border-collapse: collapse;
            font-family: 'Cormorant Garamond', serif;
        }
        .cart-table th, .cart-table td {
            border: 1px solid #d8c2b0;
            padding: 12px;
            text-align: left;
        }
        .cart-table th {
            background-color: #f5f0eb;
            color: #4c0e17;
            text-transform: uppercase;
            font-weight: 600;
        }
        .cart-image {
            width: 60px;
            height: auto;
        }
        .cart-total {
            text-align: right;
            font-size: 1.2rem;
            font-weight: 700;
            color: #4c0e17;
            margin-top: 20px;
        }
        .cart-actions {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin: 20px auto;
            width: 80%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="despre.php">Despre</a>
            <a href="contact.php">Contact</a>
        </nav>
    </header>

    <section class="section">
        <h2 class="section-title">Coșul Meu de Cumpărături</h2>
        
        <?php if (count($cart_items) > 0): ?>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Produs</th>
                        <th>Preț Unitar</th>
                        <th style="text-align: center;">Cantitate</th>
                        <th>Subtotal</th>
                        <th>Acțiuni</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                    <tr>
                        <td style="display: flex; align-items: center; gap: 10px;">
                            <img src="<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="cart-image">
                            <?php echo htmlspecialchars($item['name']); ?>
                        </td>
                        <td><?php echo number_format($item['price'], 2, ',', '.'); ?> RON</td>
                        <td style="text-align: center; white-space: nowrap;">
                            <form action="cart.php" method="POST" style="display: inline;">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <button type="submit" name="update_quantity" value="decrease" class="btn btn-small" style="padding: 5px 10px;">-</button>
                            </form>
                            <span style="display: inline-block; width: 30px; text-align: center;"><?php echo $item['quantity']; ?></span>
                            <form action="cart.php" method="POST" style="display: inline;">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <button type="submit" name="update_quantity" value="increase" class="btn btn-small" style="padding: 5px 10px;">+</button>
                            </form>
                        </td>
                        <td><?php echo number_format($item['price'] * $item['quantity'], 2, ',', '.'); ?> RON</td>
                        <td>
                            <form action="cart.php" method="POST">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <button type="submit" name="remove_item" class="btn btn-small" style="background-color: #801f2f; padding: 5px 10px;">Șterge</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="cart-total">
                Total: <?php echo number_format($total_price, 2, ',', '.'); ?> RON
            </div>
            
            <div class="cart-actions">
                <a href="magazin.php" class="btn btn-small">Continuă cumpărăturile</a>
                <a href="checkout.php" class="btn">Finalizează comanda</a>
            </div>

        <?php else: ?>
            <div class="about" style="text-align: center; margin-top: 3rem;">
                <h2>Coșul tău este gol! 🛒</h2>
                <p>Adaugă niște vinuri italienești pentru a începe aventura.</p>
                <a href="magazin.php" class="btn" style="margin-top: 1.5rem;">Mergi la Magazin</a>
            </div>
        <?php endif; ?>

    </section>

    <footer>
        &copy; <?php echo date('Y'); ?> Casa di Vini &mdash; Magazin de vinuri italiene
    </footer>
    
    <script src="script.js"></script>
</body>
</html>