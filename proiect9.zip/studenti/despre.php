<?php
session_start();
$cart_count = count($_SESSION['cart'] ?? []);
$is_logged_in = isset($_SESSION['email']);
$username = $_SESSION['username'] ?? 'Vizitator';
$profile_pic = $_SESSION['profile_pic'] ?? 'default-avatar.png';
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Despre Noi | Casa di Vini</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Cormorant+Garamond:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <header>
        <h1>Casa di Vini</h1>
        <nav>
            <a href="index.php">Acasă</a>
            <a href="magazin.php">Magazin</a>
            <a href="cart.php">Coș (<?php echo $cart_count; ?>)</a>
            <a href="contact.php">Contact</a>
        </nav>
    </header>
    <section class="section">
        <center>
            <h2 class="section-title">Povestea Casa di Vini</h2>
        </center>
        
        <div class="about">
            <h2>Pasiune pentru Eleganța Italiană</h2>
            <p>
                Casa di Vini nu este doar un magazin de vinuri, ci o poartă către inima podgoriilor italiene. Am fost fondați din dorința pură de a aduce pe mesele românilor cele mai alese și autentice vinuri, de la cele clasice și renumite, până la micile bijuterii produse de crame de familie.
            </p>
            <p>
                Credem că fiecare sticlă spune o poveste: despre solul bogat al Toscanei, despre briza marină din Sicilia și despre munca pasionată a viticultorilor care își dedică viața artei vinului. Misiunea noastră este să împărtășim aceste povești cu tine.
            </p>
        </div>

        <div class="about">
            <h2>Selecția Noastră</h2>
            <p>
                Colecția noastră este curatoriată cu grijă, punând accentul pe **calitate**, **autenticitate** și **diversitate**. Fie că ești în căutarea unui robust Barolo, a unui proaspăt Pinot Grigio sau a unui spumant rafinat Prosecco, vei găsi la noi vinul perfect pentru orice ocazie.
            </p>
            <ul>
                <li>**Roșii Elegante:** De la Chianti la Amarone.</li>
                <li>**Albe Proaspete:** Vinuri minerale și aromatice.</li>
                <li>**Spumante:** Bule fine pentru sărbătoare.</li>
                <li>**Vinuri de desert:** Experiențe dulci și memorabile.</li>
            </ul>
        </div>

        <div class="about">
            <h2>Angajamentul Nostru</h2>
            <p>
                Suntem dedicați să oferim clienților noștri nu doar produse de excelență, ci și o experiență de cumpărare plăcută și informată. Oferim livrare rapidă și sigură și suntem mereu disponibili pentru a te ajuta să alegi vinul ideal. Mulțumim că ne-ai ales să fim gazda ta în lumea vinurilor italiene!
            </p>
        </div>
        
    </section>

    <footer>
        &copy; <?php echo date('Y'); ?> Casa di Vini &mdash; Magazin de vinuri italiene
    </footer>
    
    <script src="script.js"></script>
</body>
</html>